﻿$null = New-Item -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\AutoDiscover -ErrorAction SilentlyContinue	#ALL	1	Create the Autodiscover key
$null = New-Item -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\Setup -ErrorAction SilentlyContinue	#ALL	2	Create the Setup key
$null = New-Item -Path "$env:localappdata\Google\Chrome\User Data\First Run" -ItemType Directory -ErrorAction SilentlyContinue	#ALL	3	Create Chrome First run Folder
$null = New-Item -Path "$env:localappdata\Google\Chrome\User Data\Default" -ItemType Directory -ErrorAction SilentlyContinue	#ALL	Create Chrome Default Folder
$null = "{ `"browser`": { `"has_seen_welcome_page`": true }}" | Out-File "$env:localappdata\Google\Chrome\User Data\Default\Preferences" -Force -Encoding ascii -ErrorAction SilentlyContinue 	#ALL	Create Chrome preferences entry to skip first run
$null = New-Item -Path "$env:localappdata\Microsoft\Edge\User Data\Default" -ItemType Directory -ErrorAction SilentlyContinue	#ALL	Create Edge First run Folder
$null = New-Item -Path "$env:localappdata\Microsoft\Edge\User Data\First Run" -ItemType File -ErrorAction SilentlyContinue	#ALL	Create Edge Default Folder
$null = "{`"fre`": { `"has_user_completed_fre`":true,`"has_user_seen_fre`":true }}" | Out-File "$env:localappdata\Microsoft\Edge\User Data\Local State" -Force -Encoding ascii -ErrorAction SilentlyContinue	#ALL	Create Edge Local State file to skip first run
$null = New-Item -Path "HKCU:\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN" -Force -ErrorAction SilentlyContinue	#ALL	Create internet explorer feature lockdown key
$null = New-ItemProperty -Path "HKCU:\Software\Microsoft\Internet Explorer\Main\FeatureControl\FEATURE_LOCALMACHINE_LOCKDOWN" -Name iexplore.exe -PropertyType DWORD -Value 00000000 -Force -ErrorAction SilentlyContinue	#ALL	Allow internet explorer to interact with local files
$null = New-Item -Path "HKCU:\Software\Microsoft\Office\16.0\PowerPoint\options" -Force -ErrorAction SilentlyContinue	#ALL	Create powerpoint options key
$null = New-ItemProperty -Path "HKCU:\Software\Microsoft\Office\16.0\PowerPoint\options" -Name EnableSuggestionServiceUserSetting -PropertyType DWORD -Value 00000000 -Force -ErrorAction SilentlyContinue	#ALL	Disable the office suggestion service to block design ideas
$null = Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\Setup -Name First-Run -Force -ErrorAction SilentlyContinue	#ALL	Remove First-Run value for all new profile creation to work

$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name SLRToggleReplaceTeachingCalloutID -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name UseTighterSpacingTeachingCallout -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name Olk_SearchBoxTitleBar_SLR_Sequence -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name RibbonOverflowTeachingCalloutID -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name a79db66d-e74d-41e8-a138-558044fae3cb -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name AutocreateTeachingCallout_MoreLocations -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name CloudSettingsSyncTeachingCallout -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\TeachingCallouts -Name HubBarTeachingCallout -PropertyType DWORD -Value 00000002 -Force -ErrorAction SilentlyContinue	#Hide Teaching Callouts
$null = Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\AutoDiscover -Name ZeroConfigExchange -Force -ErrorAction SilentlyContinue	#Remove Outlook Autologon
$null = Remove-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\AutoDiscover -Name ZeroConfigExchangeOnceCompleted -Force -ErrorAction SilentlyContinue	#Remove Outlook Autologon
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\Setup -Name importPRF -PropertyType String -Value $("$env:userprofile\Automai\Content\Outlook\Outlook.prf") -Force -ErrorAction SilentlyContinue	#Import the path of the PRF to configure outlook
$null = Remove-Item -Path HKCU:\Software\Microsoft\Office\16.0\Outlook\Profiles -Recurse -Force -ErrorAction SilentlyContinue	#Remove any old outlook profiles
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\General -Name ShownFirstRunOptin -PropertyType DWORD -Value 00000001 -Force -ErrorAction SilentlyContinue	#Hide the first run wizard of Outlook
$null = New-ItemProperty -Path HKCU:\Software\Microsoft\Office\16.0\Common\General -Name ShownFileFmtPrompt -PropertyType DWORD -Value 00000001 -Force -ErrorAction SilentlyContinue	#Hide the default file type XML prompt

#Outlook Social Connector Disable
$null = New-Item -Path "HKCU:\Software\Microsoft\Office\Outlook\Addins\OscAddin.Connect" -Force -ErrorAction SilentlyContinue
$null = New-ItemProperty -Path "HKCU:\Software\Microsoft\Office\Outlook\Addins\OscAddin.Connect" -Name LoadBehavior -PropertyType DWORD -Value 00000000 -Force -ErrorAction SilentlyContinue
$null = Set-ItemProperty -Path "HKCU:\Software\Microsoft\Office\Outlook\Addins\OscAddin.Connect" -Name LoadBehavior -PropertyType DWORD -Value 00000000 -Force -ErrorAction SilentlyContinue
